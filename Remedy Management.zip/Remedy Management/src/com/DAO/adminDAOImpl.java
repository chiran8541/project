package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.doa.OrclDatabase;



public class adminDAOImpl implements adminDAO{

	
	public List<String> getAllId() {
		String query = "select * from userdetails";
		Connection connection = null;
		List<String> list = new ArrayList<>();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		connection = OrclDatabase.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
				list.add(resultSet.getString(1));
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
